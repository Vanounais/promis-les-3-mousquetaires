<section>
  <h2>404</h2>
	<img src="https://media.giphy.com/media/3HLMNi9U0yb4CDldVO/giphy.gif" alt="404">
</section>