<!-- l'affichage du hero-->
<div class="hero-team">
      <h2 class="title-services"><?php the_title();?></h2>
  </div>