<!-- la page 404-->
<section>
<div class="er404-container">
        <h1 class="er404-h1">404</h1>
        <div class="er404-div">Promis ne trouve pas la page que vous désirez.</div>
    </div>
</section>